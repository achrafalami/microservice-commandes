package ma.formation.microservicecommandes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceCommandesApplicationTests {

	@Test
	void contextLoads() {
	}

}
