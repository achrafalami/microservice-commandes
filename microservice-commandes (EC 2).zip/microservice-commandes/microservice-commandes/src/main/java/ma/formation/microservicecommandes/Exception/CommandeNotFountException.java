package ma.formation.microservicecommandes.Exception;

public class CommandeNotFountException extends RuntimeException {

    public CommandeNotFountException(String message) {
        super(message);
    }
}
