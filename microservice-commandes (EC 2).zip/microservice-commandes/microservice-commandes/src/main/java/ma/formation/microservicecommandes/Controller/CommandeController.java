package ma.formation.microservicecommandes.Controller;

import ma.formation.microservicecommandes.Config.ApplicationPropertiesConfiguration;
import ma.formation.microservicecommandes.Entity.Commande;
import ma.formation.microservicecommandes.Exception.CommandeNotFountException;
import ma.formation.microservicecommandes.Repository.CommandeReposetory;
import ma.formation.microservicecommandes.Service.CommandeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import java.util.List;
import java.util.Optional;
@RestController
@EnableCircuitBreaker
@Configuration
@EnableHystrixDashboard
@RequestMapping("/api/commandes")
public class CommandeController implements HealthIndicator{

    @Autowired
    private CommandeService commandeService;
    @GetMapping("/myMessage")
    @HystrixCommand(fallbackMethod = "myHistrixbuildFallbackMessage",
            commandProperties ={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "1000")},
            threadPoolKey = "messageThreadPool")
    public String getMessage() throws InterruptedException {
        System.out.println("Message from EmployeeController.getMessage(): Begin To sleep for 3 scondes ");
        Thread.sleep(3000);
        return "Message from EmployeeController.getMessage(): End from sleep for 3 scondes ";
    }
    private String myHistrixbuildFallbackMessage() {
        return "Message from myHistrixbuildFallbackMessage() : Hystrix Fallbackmessage ( after timeout : 1 second )";
    }

    @GetMapping(value = "/{id}")
    public Commande findEleveById(@PathVariable(name = "id") Long id) {
        return commandeService.findcommandeById(id);
    }

    @GetMapping
    public List<Commande> findAll() {
        return commandeService.findAll();
    }
    @GetMapping(value = "/lastcommandes")
    public List<Commande> findLastCommandes() {
        return commandeService.findLastCommandes();
    }
    @PostMapping
    public ResponseEntity<Object> create(@Validated @RequestBody Commande commande) {
        if (commandeService.findAll().stream().filter(a->a.getId()==commande.getId()).findFirst().isPresent()){
            return ResponseEntity.notFound().build();
        }
        commandeService.create(commande);
        return new ResponseEntity<>("Commande cree avec succes", HttpStatus.CREATED);
    }
    @PutMapping(value = "/{id}")
    public ResponseEntity<Object> update(@PathVariable(name = "id") Long id, @RequestBody Commande commande) {
        try {
            commandeService.update(id, commande);
            return new ResponseEntity<>("Commande Modifiee avec succes", HttpStatus.OK);
        } catch (CommandeNotFountException  e) {
            return ResponseEntity.notFound().build();
        }
    }
    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Object> delete(@PathVariable(name = "id") Long id) {
        try {
            commandeService.delete(id);
            return new ResponseEntity<>("Commande ssupprimee avec succes", HttpStatus.OK);
        } catch (CommandeNotFountException e) {
            return ResponseEntity.notFound().build();
        }
    }
    public Health health() {
        return commandeService.health();
    }
}
