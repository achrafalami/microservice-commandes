package ma.formation.microservicecommandes.Service;

import ma.formation.microservicecommandes.Config.ApplicationPropertiesConfiguration;
import ma.formation.microservicecommandes.Entity.Commande;
import ma.formation.microservicecommandes.Exception.CommandeNotFountException;
import ma.formation.microservicecommandes.Exception.UserAlreadyExistException;
import ma.formation.microservicecommandes.Repository.CommandeReposetory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.*;

@Service
public class CommandeService implements HealthIndicator,ICommandeService{
    @Autowired
    CommandeReposetory commandeReposetory;
    @Autowired
    ApplicationPropertiesConfiguration appProperties;

    @Override
    public Commande findcommandeById(Long id) {
        Commande commande = new Commande();
        commande=commandeReposetory.findById(id).get();
        return commande;
    }

    @Override
    public List<Commande> findAll() {
        List<Commande> commandeList = new ArrayList<>();
        commandeList = commandeReposetory.findAll();
        List<Commande> listeCommande = commandeList.subList(0, appProperties.getLimitDeCommandes());
        return listeCommande;
    }

    @Override
    public void create(Commande commande) {
        if (commandeReposetory.findById(commande.getId()).isPresent()){
            new UserAlreadyExistException("Ce commande exist deja");
        }
        commandeReposetory.save(commande);
    }

    @Override
    public void update(Long id, Commande commande) {
        Optional<Commande> existingcommandeOptional = commandeReposetory.findById(id);
        if (existingcommandeOptional.isPresent()) {
            Commande existingcommande = existingcommandeOptional.get();
            existingcommande.setQuantite(commande.getQuantite());
            existingcommande.setDate(commande.getDate());
            existingcommande.setMontant(commande.getMontant());
            existingcommande.setDescription(commande.getDescription());
            commandeReposetory.save(existingcommande);
        } else {
            throw new CommandeNotFountException("commande n'existe pas contenant l'id :" + id);
        }

    }

    @Override
    public void delete(Long id) {
        Optional<Commande> existingcommandeOptional = commandeReposetory.findById(id);
        if (existingcommandeOptional.isPresent()) {
            commandeReposetory.deleteById(id);
        } else {
            throw new CommandeNotFountException("commande n'existe pas contenant l'id :" + id);
        }

    }

    @Override
    public List<Commande> findLastCommandes() {
        List<Commande> commandeList = new ArrayList<>();
        commandeList=commandeReposetory.findAll();
        Collections.sort(commandeList, Comparator.comparing(Commande::getDate).reversed());
        // Récupérez les n dernières commandes
        return commandeList.subList(0, Math.min(appProperties.getLimitDeCommandes(), commandeList.size()));
    }


    @Override
    public Health health() {
        List<Commande> Commandes = commandeReposetory.findAll();
        if (Commandes.isEmpty()) {
            return Health.down().build();
        }
        return Health.up().build();
    }


}
