package ma.formation.microservicecommandes.Service;

import ma.formation.microservicecommandes.Config.ApplicationPropertiesConfiguration;
import ma.formation.microservicecommandes.Entity.Commande;
import ma.formation.microservicecommandes.Exception.CommandeNotFountException;
import ma.formation.microservicecommandes.Exception.UserAlreadyExistException;
import ma.formation.microservicecommandes.Repository.CommandeReposetory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public interface ICommandeService {

        public Commande findcommandeById(Long id) ;
        public List<Commande> findAll() ;
        public void create(Commande commande) ;
        public void update(Long id, Commande commande);
        public void delete(Long id);
        public List<Commande> findLastCommandes() ;
        public Health health();


}
