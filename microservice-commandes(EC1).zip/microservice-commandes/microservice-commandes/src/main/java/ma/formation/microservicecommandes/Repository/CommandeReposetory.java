package ma.formation.microservicecommandes.Repository;

import ma.formation.microservicecommandes.Entity.Commande;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CommandeReposetory extends JpaRepository<Commande,Long> {

}
