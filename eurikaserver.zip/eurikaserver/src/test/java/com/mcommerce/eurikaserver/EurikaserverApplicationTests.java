package com.mcommerce.eurikaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurikaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
